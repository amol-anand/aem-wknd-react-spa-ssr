self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f79928a3f773d5cf4c4e35d5ba46bee7",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/index.html"
  },
  {
    "revision": "418487974b8f9785f4d3",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/css/main.2feada98.chunk.css"
  },
  {
    "revision": "d4b82793243fc7c58b9a",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.71d94c52.chunk.js"
  },
  {
    "revision": "0ec9300b90a1964ccb21b13048e7fb5c",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.71d94c52.chunk.js.LICENSE.txt"
  },
  {
    "revision": "418487974b8f9785f4d3",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/main.8c560415.chunk.js"
  },
  {
    "revision": "947a28bbb1bf3d46b68d",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/runtime-main.b0e1d401.js"
  },
  {
    "revision": "19a5bdabd660fde16554c866e650eadc",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/media/icon-back.19a5bdab.svg"
  }
]);